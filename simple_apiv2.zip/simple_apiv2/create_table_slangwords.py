# import module 
import sqlite3
import pandas as pd 

#create connection to database
conn = sqlite3.connect('simple_apiv2\data\slang.db')

try:
    #create table
    conn.execute("""create table slangwords (alay varchar(255), normal varchar(255));""")
    print("Table slang created")
except:
    #if exist, do nothing
    print("Table slang already exist")
#import data to dataframe
dfs = pd.read_csv("simple_apiv2/data/new_kamusalay.csv", names = ['alay', 'normal'], encoding = 'latin-1', header = None)
#import df to db
dfs.to_sql(name='slangwords', con=conn, if_exists = 'replace', index = False)
print ("---Table Slang Done---")

#----------------------------------------------------------------------------------------------------------

try:
    #create table
    conn.execute("""create table abusiv4 (ABUSIVE varchar(255));""")
    print("Table abusive created")
except:
    #if exist, do nothing
    print("Table abusive already exist")

#import data to dataframe
dfa = pd.read_csv("simple_apiv2/data/abusive.csv", encoding = 'latin-1')

#import df to db
dfa.to_sql(name='ABUSIVE', con=conn, if_exists = 'replace', index = False)
print("---Table Abusive Done---")
conn.commit()
conn.close()