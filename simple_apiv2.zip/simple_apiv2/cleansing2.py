def clean_abusive(text,df_abusive):
    
    #create empty array
    holder = [] 
    
    for word in text.split(' '):
        #check if input word exist in dictionary key
        if word in df_abusive.keys():
            #if exist, convert with realworld
            del word
        else :
            #if not, fill the empty array
            holder.append(word) 
            
    return ' '.join(holder) #string converted slang words with real words