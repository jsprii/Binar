import re
import sqlite3
import pandas as pd
from cleansing import clean_slang
from cleansing2 import clean_abusive
import os
from os.path import join, dirname, realpath

from flask import Flask, jsonify

app = Flask(__name__)
app.config["DEBUG"] = True
UPLOAD_FOLDER = 'D:/Microsoft VS Code/Binar/simple_apiv2/static/files'
app.config['UPLOAD_FOLDER'] =  UPLOAD_FOLDER

from flask import request
from flasgger import Swagger, LazyString, LazyJSONEncoder
from flasgger import swag_from

@app.route('/')
def hello():
    return "Hi! Selamat Datang 👋"

app.json_encoder = LazyJSONEncoder
swagger_template = dict(
    info = {
        'title': LazyString(lambda: 'API Documentation for Data Processing and Modeling'),
        'version': LazyString(lambda: '2.0.0'),
        'description': LazyString(lambda: 'Dokumentasi API untuk Data Processing dan Modeling'),
    },
    host = LazyString(lambda: request.host)
)
swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'docs',
            "route": '/docs.json'
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/docs/"
}
swagger = Swagger(app, template=swagger_template,config=swagger_config)


@swag_from("docs/text_processing.yml", methods=['POST'])
@app.route('/text-processing', methods=['POST'])
def text_processing():
    conn = sqlite3.connect('simple_apiv2\data\slang.db')
    df_slang = pd.read_sql('''SELECT * FROM slangwords''', conn)
    conn2 = sqlite3.connect('simple_apiv2/data/abusive.db')
    df_abusive = pd.read_sql('''SELECT * FROM abusive''', conn2)
    conn.close()
    conn2.close()

    text = request.form.get('text')

    json_response = {
        'status_code': 200,
        'description': "Original Teks",
        'data': re.sub(
         r'[^a-zA-Z0-9]', ' ', clean_slang(text,df_slang), clean_abusive(text,df_abusive))
    }
    
    response_data = jsonify(json_response)
    return response_data

@swag_from("docs/data.yml", methods=['POST'])
@app.route("/uploadfiles", methods=['POST'])
def uploadFiles():
      conn = sqlite3.connect('simple_apiv2\data\slang.db')
      # get the uploaded file
      uploaded_file = request.files['file']
      if uploaded_file.filename != '':
           file_path = os.path.join(app.config['UPLOAD_FOLDER'], uploaded_file.filename)
          # set the file path
           uploaded_file.save(file_path)
          # save the file
           df = pd.read_csv(file_path,encoding='latin-1', sep=";")
      return str(df)

if (__name__ == '__main__'):
    app.run(debug=True)
